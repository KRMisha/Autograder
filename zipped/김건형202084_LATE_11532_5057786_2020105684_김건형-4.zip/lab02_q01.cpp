#include <iostream>

using namespace std;

int main()
{
    string name = "김건형";

    cout << "My name is " << name << endl;
}