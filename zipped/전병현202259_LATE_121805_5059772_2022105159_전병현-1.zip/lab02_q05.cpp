#include<iostream>
using namespace std;


int main()
{
	float A;
	cout << "Please enter Fahrenheit value: ";
	cin >> A;
	cout << "Celsius value is " << 5.0f / 9.0f* (A - 32) << endl;

}