#include <iostream>
using namespace std;
int main()
{
	int A;
	cout << "Please enter Fehrenheit value : ";
	cin >> A;
	cout << "Celsius value is " << 5/9 * (A-32) << endl;
}

