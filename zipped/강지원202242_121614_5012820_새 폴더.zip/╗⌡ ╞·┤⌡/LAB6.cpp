#include <iostream>

using namespace std;

int main()
{
	string str;
	
    cin >> str;
    cout << str;
    
	return 0;   
}
