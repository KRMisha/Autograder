#include <iostream>
using namespace std;

int main() {
    cout<<"My name is 신승현"<<endl;
}