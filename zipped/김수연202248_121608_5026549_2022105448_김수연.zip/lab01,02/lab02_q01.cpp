#include <iostream>
using namespace std;

int main() {
	string name = "Kim Su Yeon";
	cout << "My name is " << name;
}