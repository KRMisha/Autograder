#include <iostream>
using namespace std;

int main() {
	int A, B, A_, B_;
	cout << "Please enter two integer values:" << endl;
	cout << "A : ";
	cin >> A;
	cout << "B : ";
	cin >> B;
	A_ = B;
	B_ = A;
	cout << "value of A is : " << A_ << endl;
	cout << "value of B is : " << B_;
}