#include<iostream>
#include<algorithm>
#include<cctype>

#include<cmath>
using namespace std;

int main() {

	int x, y;
	x = 10;
	y = 20;
	cout << x << endl;
	cout << y << endl;

}