#include<iostream>

using namespace std;


int main() {

	std::cout << "Please enter two integer values:" << std::endl;
	int A, B;
	std::cin >> A >> B;
	std::cout << "A: " << A << endl;
	std::cout << "B: " << B << endl;
	std::cout << "value of A is: " << B << endl;
	std::cout << "value of B is: " << A << endl;
}