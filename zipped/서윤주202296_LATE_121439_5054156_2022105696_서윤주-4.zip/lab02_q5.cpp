#include<iostream>
using namespace std;

int main() {
	int a;
	cout << "Please enter Fahrenheit value: ";
	cin >> a;
	cout << "Celsius value is " << 5.0 / 9.0 * (a - 32);
}