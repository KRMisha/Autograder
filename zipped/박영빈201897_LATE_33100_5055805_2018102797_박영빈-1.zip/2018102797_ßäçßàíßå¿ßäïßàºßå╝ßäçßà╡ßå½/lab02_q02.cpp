#include<iostream>
using namespace std;
int main() {
    int A, B;
    cin >> A >> B;
    cout << "A + B= " << A+B << endl;
    cout << "A - B= " << A-B << endl;
    cout << "A * B= " << A*B << endl;
    cout << "x / y= " << A/B << endl;
    cout << "A % B= " << A%B << endl;
    }