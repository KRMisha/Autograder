#include <iostream>
using namespace std;

int main()
{
	string name;
	cin >> name;
	cout << "My name is " << name << endl;
}