#include <iostream>
using namespace std;

int main()
{
	int A, B;
	cout << "Write two integers A and B " << endl;
	cout << "A: ";
	cin >> A;
	cout << "B: ";
	cin >> B;
	cout << "A = " << B << endl;
	cout << "B = " << A << endl;
	return 0;
}