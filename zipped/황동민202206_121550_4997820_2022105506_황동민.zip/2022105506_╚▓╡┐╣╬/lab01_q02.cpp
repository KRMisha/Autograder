/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

//sizeof :데이터 타입의 크기를 반환하는 함수

int main()
{
    
    unsigned short siX;
    unsigned iX;
    long liX;
    long long lliX;

    cout<< "sizeof(siX):"<< sizeof(siX) << endl;
    cout<< "sizeof(iX):"<< sizeof(iX) << endl;
    cout<< "sizeof(liX):"<< sizeof(liX) << endl;
    cout<< "sizeof(lliX):"<< sizeof(lliX) << endl;
    
    
    return 0;
}


