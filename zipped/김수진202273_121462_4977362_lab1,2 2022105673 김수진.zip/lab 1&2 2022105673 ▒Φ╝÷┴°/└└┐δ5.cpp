#include <iostream>
using namespace std;

int main() {
	int A;
	cout << "Please enter Fahrenheit value : ";
	cin >> A;
	cout << "Celsius value is " << 5 / 9 * (A - 32);
}