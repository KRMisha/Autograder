#include<iostream>
using namespace std;

int main() {
	string a = "Hyung Jun Park";
	cout << "My name is " << a;
}