#include <iostream>

using namespace std;


int main() {
	int Fah;

	cout << "Please enter Fahrenheit value: ";
	cin >> Fah;
	cout << "Celsius value is " << 5.0f/9.0f * ( Fah - 32 );

}

