#include <iostream>
using namespace std;
int main() {
    int a;
    int b;
    cout << "Please enter the length of the rectangle : ";
    cin >> a;
    cout << "Please enter the length of the rectangle : ";
    cin >> b;
    cout <<a + b << endl;
    cout <<a - b << endl;
    cout <<a * b << endl;
    cout <<a / b << endl;
    cout <<a % b << endl;
}
