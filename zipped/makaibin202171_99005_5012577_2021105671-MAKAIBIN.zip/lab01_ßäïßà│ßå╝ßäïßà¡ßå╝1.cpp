#include <iostream>
int main() {
    std::cout << "MY NAME IS 마해빈";
}
