#include <iostream>
using namespace std;

int main(){
    double fat;
    cout << "Please enter Fahrenheit value: "; cin >> fat;
    cout << "Celsius value is " << 5.0/9.0 * (fat-32);
}