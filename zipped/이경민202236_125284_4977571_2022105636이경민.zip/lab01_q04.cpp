#include <iostream>
using namespace std;

int main() {
	const double PI=3.14;
	char ch1 = 65;
	char ch2 = ch1 + 32;
	cout << PI << endl;
	cout << ch1 <<endl;
	cout << ch2 << endl;
}