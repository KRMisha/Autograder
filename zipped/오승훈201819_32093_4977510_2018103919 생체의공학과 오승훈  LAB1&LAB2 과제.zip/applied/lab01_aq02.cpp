#include <iostream>
using namespace std;

int main(void)
{
	int A, B;
	cout << "please enter two integer values:";
	cin >> A >> B;
	cout <<A<<" + " << B << " = " << A + B << endl;
	cout << A << " - "  << B << " = " << A - B << endl;
	cout << A << " * " << B << " = " << A * B << endl;
	cout << A << " / " << B << " = " << A / B << endl;
	cout << A << " % " << B << " = " << A % B << endl;

	return 0;
}
