#include <iostream>
using namespace std;

int main() {
	int a, b;

	cin >> a >> b;
	cout << "1) A+B : " << a + b<< endl;
	cout << "2) A-B : " << a - b << endl;
	cout << "3) A*B : " << a * b << endl;
	cout << "4) A/B : " << a / b << endl;
	cout << "5) A%B : " << a % b << endl;
}