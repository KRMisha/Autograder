#include <iostream>
using namespace std;
int a;
int b;
int main() {
    cout<<"Please enter two values: "<<endl;
    cout<<"A: "<<endl;
    cin>>a;
    cout<<"B: "<<endl;
    cin>>b;

    cout<<"value of A is: "<<b<<endl;
    cout<<"value of B is: "<<a<<endl;

}