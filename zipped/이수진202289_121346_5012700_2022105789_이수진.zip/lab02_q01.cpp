﻿#include <iostream>
using namespace std;

int main() {
	cout << "My name is 이수진" << endl;
}
