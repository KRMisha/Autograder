#include <iostream>
using namespace std;
int main() {
    printf("my name is 김동원");
}