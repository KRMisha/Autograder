#include <iostream>
using namespace std;
int a,b;
int main(){
    cin >> a >> b;
    cout << "a + b = "<<a+b <<endl;
    cout << "a * b = "<<a-b <<endl;
    cout << "a * b = "<<a*b <<endl;
    cout << "a / b = "<<a/b <<endl;
    cout << "a % b = "<<a%b;
    return 0;
}