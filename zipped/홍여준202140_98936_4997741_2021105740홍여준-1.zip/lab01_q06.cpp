#include <iostream>
using namespace std;

int main() {
    string name = "홍여준";
    cout << "My name is " << name;
}
