#include <iostream>

using namespace std;

int main() {
	int F;
	cin >> F;
	cout << "Celsius value is :" << F - 32 << endl;
}

