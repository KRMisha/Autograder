#include <iostream>

using namespace std;

int main() {
	int A, B;
	cin >> A >> B;
	cout << "value of A is :" << B << endl;
	cout << "value of B is :" << A << endl;
}

