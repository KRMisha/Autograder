#include <iostream>

using namespace std;

int main() {
	unsigned short siX;
	unsigned iX;
	long liX;
	long long lliX;
	cout << "sizeof(siX):" << sizeof(siX) << "\n";
	cout << "sizeof(iX):" << sizeof(iX) << "\n";
	cout << "sizeof(liX):" << sizeof(liX) << "\n";
	cout << "sizeof(lliX):" << sizeof(lliX) << "\n";
}



