#include <iostream>

using namespace std;

int main() {
	cout << "(7 == 5):" << 0 << endl;
	cout << "(7 >= 5):" << 1 << endl;
	cout << "(7 != 5):" << 1 << endl;
	cout << "(7 <= 5):" << 0 << endl;
	cout << "(7 >= 5 ? 100 : -100): " << 100 << endl;
}

