#include <iostream>

using namespace std;

int main() {
	int A, B;
	cout<< "Please enter two integer values:" << '\n';
	cout << "A :";
	cin >> A;
	cout << "B :";
	cin >> B;
	A = B;
	B = 30;
	cout << "value of A is : " << A << '\n';
	cout << "value of B is : " << B;


}



