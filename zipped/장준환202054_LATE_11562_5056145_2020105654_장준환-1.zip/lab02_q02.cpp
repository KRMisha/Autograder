#include <iostream>

using namespace std;

int main() {
	int A, B;
	cout << "Please enter two integer values:";
	cin >> A>> B;
	cout << A<< "+" << B<< " = " << A + B << "\n";
	cout << A<< "-" <<B<< " =" << A - B << "\n";
	cout << A <<" *"<< B<<" =" << A * B << '\n';
	cout << A <<" /"<< B<<" =" << A / B << '\n';
	cout << A <<"%"<< B<<" =" << A % B << '\n';

}



