#include <iostream>

using namespace std;

int main() {
	double A;
	cout << "Please enter Fahrenheit value: ";
	cin >> A;
	cout << "Celsius value is " << 5.0 / 9.0 * (A - 32);




}



