﻿#include <iostream>
using namespace std;

int main() {
	string name;
	name = "김범수";
	cout << "My name is " << name;
}