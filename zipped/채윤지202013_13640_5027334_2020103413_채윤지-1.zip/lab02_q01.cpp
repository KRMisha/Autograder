#include <iostream>

using namespace std;
int main() {
	char ch1[7] = "ä����";
	cout << "My name is " << ch1 << '\n';
}