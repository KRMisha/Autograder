#include <iostream>
using namespace std;
int main() {
	cout << "(7 == 5):" << 3 << '\n';
	cout << "(7 >= 5):" << 4 << '\n';
	cout << "(7 != 5):" << 5 << '\n';
	cout << "(7>=5):" << 6 << '\n';
	cout << "(7 >= 5 ? 7 : 5):" << 7 << '\n';
}