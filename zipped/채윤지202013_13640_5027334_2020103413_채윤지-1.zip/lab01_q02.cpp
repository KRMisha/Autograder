#include <iostream>

using namespace std;
int main() {
	unsigned short siX;
	unsigned iX;
	long liX;
	long long lliX;
	cout << "sizeof(siX):" << 2 << '\n';
	cout << "sizeof(iX):" << 4 << '\n';
	cout << "sizeof(liX):" << 6 << '\n';
	cout << "sizeof(lliX):" << 8 << '\n';
}