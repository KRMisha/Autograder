﻿#include <iostream>
using namespace std;

int main() {
	cout << "Please enter two integer values: ";
	int A, B;
	cin >> A >> B;
	cout << A << " + " << B << " = " << A + B << endl;
	cout << A << " - " << B << " = " << A - B << endl;
	cout << A << " * " << B << " = " << A * B << endl;
	cout << A << " / " << B << " = " << A / B << endl;
	cout << A << " % " << B << " = " << A % B << endl;
}