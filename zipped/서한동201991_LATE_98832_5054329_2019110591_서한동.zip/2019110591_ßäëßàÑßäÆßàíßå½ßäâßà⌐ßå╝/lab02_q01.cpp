#include <iostream>
using namespace std;

int main() {
	cout << "My name is ���ѵ�" << endl;
}
