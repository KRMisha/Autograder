//
//  main.cpp
//  q9
//
//  Created by 김우진 on 2023/03/09.
//

#include <iostream>
using namespace std;
int main(){
    int a,b,c;
    cout<<"Please enter two integer values:\n";
    cin>>a>>b;
    cout<<"A: "<<a<<"\n";
    cout<<"B: "<<b<<"\n";
    c=a;
    a=b;
    b=c;
    cout<<"value of A is: "<<a<<"\n";
    cout<<"value of B is: "<<b;

    
    
    
}
