//
//  main.cpp
//  q1
//
//  Created by 김우진 on 2023/03/09.
//

#include <iostream>
using namespace std;
int main(){
    int x,y;
    x=10;
    y=20;
    cout<<x<<"\n";
    cout<<y<<"\n";
}
