//
//  main.cpp
//  q6
//
//  Created by 김우진 on 2023/03/09.
//

#include <iostream>
using namespace std;
int main(){
    cout<<"My name is 김우진";
}
