//
//  main.cpp
//  q4
//
//  Created by 김우진 on 2023/03/09.
//
using namespace std;
#include <iostream>
int main() {
    /*구현: PI를 상수(const)로 선언*/
    const float PI=3.14;
    
    char ch1 = 65;
    char ch2 = ch1+32;
    cout << PI << endl;
    cout << ch1 << endl;
    cout << ch2 << endl;
}
