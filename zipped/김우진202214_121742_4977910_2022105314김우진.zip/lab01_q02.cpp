//
//  main.cpp
//  q2
//
//  Created by 김우진 on 2023/03/09.
//
//sizeof()함수는 변수 또는 자료형의 크기를 알려준다.
#include <iostream>
using namespace std;
int main() {
unsigned short siX;
    unsigned iX;
long liX;
long long lliX;
cout << "sizeof(siX):" << sizeof(siX) << endl;
    cout << "sizeof(iX):" <<sizeof(iX)  << endl;
    cout << "sizeof(liX):" << sizeof(liX) << endl;
    cout << "sizeof(lliX):" << sizeof(lliX) << endl;
}
