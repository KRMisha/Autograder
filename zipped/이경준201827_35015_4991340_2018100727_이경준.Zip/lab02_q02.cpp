#include <iostream>

int main(void) {
	int A,B;
	std::cout << "Please enter two integer values: ";
	std::cin >> A >> B;
	std::cout << A << " + " << B << " = " << A + B << std::endl;
	std::cout << A << " - " << B << " = " << A - B << std::endl;
	std::cout << A << " * " << B << " = " << A * B << std::endl;
	std::cout << A << " / " << B << " = " << A / B << std::endl;
	std::cout << A << " % " << B << " = " << A % B << std::endl;
}