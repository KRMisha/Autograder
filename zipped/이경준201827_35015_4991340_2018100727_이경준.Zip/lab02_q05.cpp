#include <iostream>
using namespace std;

int main(void) {
	double celsius, fahrenheit;
	cout << "Please enter Fahrenheit value: ";
	cin >> fahrenheit;
	celsius = (double) 5.0 / 9.0 * (fahrenheit - 32);
	cout << "Celsius value is " << celsius;
}