#include <iostream>
using namespace std;

int main(void) {
	int A, B,c;
	cout << "Please enter two integer values: " << endl;
	cout << "A : ";
	cin >> A;
	cout << "B : ";
	cin >> B;
	c = A;
	A = B;
	B = c;
	cout << "value of A is : " << A << endl;
	cout << "value of B is : " << B << endl;
}