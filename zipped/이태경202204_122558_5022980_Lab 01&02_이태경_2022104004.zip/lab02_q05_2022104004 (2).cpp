﻿#include <iostream>

using namespace std;

﻿int main() {
	unsigned short siX; // (int) 생략 가능
	unsigned iX;
	long liX;
	long long lliX;
	cout << "sizeof(siX):" << short int << endl;
	cout << "sizeof(iX):" << int << endl;
	cout << "sizeof(liX):" << long int/ << endl;
	cout << "sizeof(lliX):" << long long int << endl;
}