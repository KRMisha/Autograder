#include <iostream>

using namespace std;

int main() {
	int A, B;
	cout << "Please enter two integers:" << endl;
	cout << "A:" << endl;
	cin >> A;
	cout << "B:" << endl;
	cin >> B;
	cout << "value of A is" << A << endl;
	cout << "value of B is" << B << endl;
}