#include <iostream>
using namespace std;

int main()
{
	int f;
	cout << "Please enter Farenheit value: ";
	cin >> f;
	cout << "Celsius value is " << 5.0 / 9.0 * (f - 32) << endl;
	return 0;
}