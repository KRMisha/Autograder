#include <iostream>

using namespace std;

int main() {
    int A, B;
    cout << "Please enter two integer values: " << endl;
    cout << "A : ";
    cin >> A;
    cout << "B : ";
    cin >> B;
    cout << "value of A is : " << B << endl;
    cout << "value of B is : " << A << endl;
}


