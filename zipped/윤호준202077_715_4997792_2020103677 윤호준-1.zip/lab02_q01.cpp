#include <iostream>

using namespace std;

int main() {
	string name;
	name = "��ȣ��";
	cout << "My name is " << name << endl;
}

