#include <iostream>
using namespace std;

int main() {
    cout << "My name is 홍민혁" << endl;
}
