﻿#include <iostream>
using namespace std;

int main() {
	unsigned short siX; // (int) 생략 가능
	unsigned iX;
	long liX;
	long long lliX;
	cout << "sizeof(siX):" <<2 << endl;
	cout << "sizeof(iX):" << 4<< endl;
	cout << "sizeof(liX):" << 4 << endl;
	cout << "sizeof(lliX):" << 8 << endl;
}
