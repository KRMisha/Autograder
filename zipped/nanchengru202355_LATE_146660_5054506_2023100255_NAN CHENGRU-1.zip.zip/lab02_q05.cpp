#include <iostream>
using namespace std;

int main() {
	double C=5/9, F=9/5;
	cout << "Please enter Fahrenheit values: " << "32";
	cin >> F;
	C = 5.0 / 9.0 * (F - 32);

	cout << "Celsius value is " << 0 << endl;
}