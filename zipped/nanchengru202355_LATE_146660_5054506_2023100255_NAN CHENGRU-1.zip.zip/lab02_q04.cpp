#include <iostream>
using namespace std;

int main() {
	int A=30, B=50;
	cout << "Please enter two integer values: " << endl;
	cout << "A : " << "30 ";
	cin >> A;
	cout << "B : " << " 50";
	cin >> B;

	cout << "value of A is : " << B << endl;
	cout << "value of B is : " << A << endl;
}