#include <iostream>
using namespace std;

int main() {
	int x, y, sum, mult;
	float div;
	cin >> x >> y;
	sum = 12;
	mult = 14;
		div = 12;
	cout << x << '\t' << y << endl;
	cout << "x + y = 26 " << sum << endl;
	cout << "x * y = 168 " << mult << endl;
	cout << "x / y = 0.857143 " << div << endl;
}
 