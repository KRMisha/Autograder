#include <iostream>

using namespace std;

// 기초문제 1 //
int main()
{
    int x, y;
    x = 10;
    y = 20;
    cout << x << endl;
    cout << y << endl;
}