#include <iostream>
#define endl '\n'
using namespace std;

int main() {
	int x, y;  
	x = 10; /*구현*/
	y = 20; /*구현*/
	cout << x << endl;
	cout << y << endl;
}
