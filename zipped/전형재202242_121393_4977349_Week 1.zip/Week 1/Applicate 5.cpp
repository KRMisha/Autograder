#include <iostream>
#define endl '\n'
using namespace std;

int F;

int main(){

    cout << "Please enter Fahrenheit value :";
    cin >> F;
    cout << "Celsius value is " << 5/9 * (F - 32);

    return 0;
}