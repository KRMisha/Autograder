#include <iostream>
using namespace std;

int main(){

    cout << "My name is 전형재";

    return 0;
}