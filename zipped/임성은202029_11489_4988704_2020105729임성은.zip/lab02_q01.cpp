#include <iostream>
using namespace std;
int main() {
	char name[100];
	cin >> name;
	cout << "My name is " << name << endl;
}