#include <iostream>

using namespace std;

int main()
{
    cout << "My name is 정찬일" << endl;

    return 0;
}