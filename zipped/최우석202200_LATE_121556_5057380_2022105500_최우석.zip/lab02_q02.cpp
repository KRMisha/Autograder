//
//  main.cpp
//  sol_extend_2
//
//  Created by 최우석 on 2023/03/09.
//

#include <iostream>
using namespace std;
int main(int argc, const char * argv[]) {
    int value1, value2;
    cout << "Please enter two integer values: ";
    cin >> value1 >> value2;
    cout << value1 << " + " << value2 << " = " << value1 + value2 << endl;
    cout << value1 << " - " << value2 << " = " << value1 - value2 << endl;
    cout << value1 << " * " << value2 << " = " << value1 * value2 << endl;
    cout << value1 << " / " << value2 << " = " << value1 / value2 << endl;
    cout << value1 << " % " << value2 << " = " << 6value1 % value2 << endl;
    return 0;
}
