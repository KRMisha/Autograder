//
//  main.cpp
//  sol_extend_1
//
//  Created by 최우석 on 2023/03/09.
//

#include <iostream>
using namespace std;
int main(int argc, const char * argv[]) {
    // insert code here...
    cout << "My name is 최우석";
    return 0;
}
