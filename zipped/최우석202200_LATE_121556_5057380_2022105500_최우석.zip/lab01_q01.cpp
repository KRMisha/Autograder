//
//  main.cpp
//  sol1
//
//  Created by 최우석 on 2023/03/09.
//

#include <iostream>
using namespace std;

int main() {
    int x, y;
    x = 10;
    y = 20;
    cout << x << endl;
    cout << y << endl;
}

