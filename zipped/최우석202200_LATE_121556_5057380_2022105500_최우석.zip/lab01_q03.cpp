//
//  main.cpp
//  sol3
//
//  Created by 최우석 on 2023/03/09.
//

#include <iostream>
using namespace std;
int main() {
    cout << "(7 == 5):" << (7 == 5) << endl;
    cout << "(7 >= 5):" << (7 >= 5) << endl;
    cout << "(7 != 5):" << (7 != 5) << endl;
    cout << "(7 <= 5):" << (7 <= 5) << endl;
    cout << "(7 >= 5 ? 100 : -100): " << (7 >= 5 ? 100 : -100) << endl;
}
