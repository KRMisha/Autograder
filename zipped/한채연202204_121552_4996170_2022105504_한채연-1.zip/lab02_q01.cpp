#include <iostream>
#include<string>
using namespace std;

int main() {
	cout << "My name is ��ä��";
}