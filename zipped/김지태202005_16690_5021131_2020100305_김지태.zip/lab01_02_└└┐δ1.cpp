#include <iostream>
using namespace std;
int main(){
    cout<<"My name is 김지태"<<endl;
}