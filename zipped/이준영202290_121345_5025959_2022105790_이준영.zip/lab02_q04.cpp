#include <iostream>
using namespace std;

int main() {
	int A, B;
	cout << "Please enter two integer values: " << endl;
	cout << "A : ";
	cin >> A;
	cout << "B : ";
	cin >> B;
	cout << "Value of A is : " << B << endl;
	cout << "Value of B is : " << A << endl;
}