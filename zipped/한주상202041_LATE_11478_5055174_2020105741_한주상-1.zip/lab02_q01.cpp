#include <iostream>
using namespace std;

int main() {
	string my_name;
	my_name = "Han Jusang";
	cout << "My name is " << my_name << endl;
}