#include <iostream>
using namespace std;

int main() {
	cout << "MY name is �ڹλ�" << endl;
}
