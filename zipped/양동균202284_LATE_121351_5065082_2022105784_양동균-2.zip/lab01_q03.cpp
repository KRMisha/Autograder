#include <iostream>

using namespace std;
// �ڷ��� ũ�� ǥ���ϴ� �Լ�
int main() {
	cout << "(7 == 5):" << (7 == 5) << endl;
	cout << "(7 >= 5):" << (7 >= 5) << endl;
	cout << "(7 != 5):" << (7 != 5) << endl;
	cout << "(7 <= 5):" << (7 <= 5) << endl;
	cout << "(7 >= 5 ? 100 : -100): " << (7 >= 5 ? 100 : -100) << endl;
}