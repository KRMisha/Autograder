#include <iostream>

using namespace std;

int main() {

	float Fahrenheit, Celsius;

	cout << "Plese enter Fahrenheit value : ";
	cin >> Fahrenheit;

	cout << "Celsius vlaue is " << (float)5 / (float)9 * (Fahrenheit - 32);
}