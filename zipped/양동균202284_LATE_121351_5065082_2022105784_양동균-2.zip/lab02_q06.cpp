#include <iostream>

using namespace std;

int main() {
	cout << "my name is �絿��";
}