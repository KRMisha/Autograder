#include <iostream>

using namespace std;

int main() {
        int A, B;
        cin >> A >> B;
        std::cout <<"Please enter two integer values" << "\nA : "<< A << "\nB : " << B << endl; 
        std::cout << "value of A is : " << B << endl;
        std::cout << "value of B is : " << A << endl;
}