#include <iostream>

using namespace std;

int main() { 
        const float(PI)=3.14;
        char ch1 = 65; char ch2 = 65+32; 
        std::cout << PI << endl;
        std::cout << ch1 << endl;
        std::cout << ch2 << endl;
}
