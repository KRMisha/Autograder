#include <iostream>

using namespace std;

int main() {
    std::cout << "My name is 김민섭" << endl;
    }
        