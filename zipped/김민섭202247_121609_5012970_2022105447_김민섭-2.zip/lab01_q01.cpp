#include <iostream>

using namespace std;

int main() {       
        
        int x, y;
        x = 10;
        y = 20;
        std::cout << x << endl; 
        std::cout << y << endl;
}