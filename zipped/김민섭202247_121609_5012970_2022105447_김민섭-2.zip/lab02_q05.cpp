#include <iostream>

using namespace std;

int main() {
        float A,B;
        cin >> A;
        B=5.0f/9.0f*(A-32.0f);
        std::cout <<"Please enter Farenheit value: " << A << endl; 
        std::cout <<"celcius value is " << B << endl;
}