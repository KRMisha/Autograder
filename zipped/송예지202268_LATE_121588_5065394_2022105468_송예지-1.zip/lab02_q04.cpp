#include <iostream>

using namespace std;

int main() {
	int a, b;
	cout << "Please enter two integer value: " << endl;
	cout << "A : ";
	cin >> a;
	cout << "B : ";
	cin >> b;
	cout << "value of A is : " << b << endl;
	cout << "value of B is : " << a << endl;
}